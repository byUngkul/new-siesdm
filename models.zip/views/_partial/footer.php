<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.1
    </div>
    <strong>Copyright &copy; 2019 <a href="https://bukan-dunia-tekno.blogspot.com/">ASDF Project</a>.</strong> All rights
    reserved.
  </footer>