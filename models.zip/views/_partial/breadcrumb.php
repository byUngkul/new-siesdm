<section class="content-header">
  <h1>
    <?=$page;?>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?=base_url('dashboard')?>"><i class="fa fa-home"></i><?=$sub_title;?></a></li>
    <li class="active"><?=$page;?></li>
  </ol>
</section>