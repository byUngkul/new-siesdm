<?php 
/**
 * class controller sumur
 */
class Sumur extends CI_Controller{
	
	function __construct(){
		parent::__construct();
		if ($this->session->userdata('masuk') != TRUE){
			redirect('login');
		}
		$this->load->model('sumur_model', 'sumur');
		$this->load->model('perusahaan_model', 'prs');
		$this->load->model('jenis_sumur_model', 'jenis');
	}

	public function index(){
		// akses admin
		if($this->session->userdata('akses')=='1'){
			if (isset($_GET['filter1']) && !empty($_GET['filter1'])) {
				$filter = $_GET['filter1'];

				if ($filter == '1') {
					$wil        = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$url_cetak  = 'sumur/cetak?filter=1&wilayah='.$wil;
					$url_excel  = 'sumur/excel?filter=1&wilayah='.$wil;
					$wilayah    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2'){
					$perusahaan = $_GET['perusahaan'];
					$url_cetak  = 'sumur/cetak?filter=2&perusahaan='.$perusahaan;
					$url_excel  = 'sumur/excel?filter=2&perusahaan='.$perusahaan;
					$nama_prs   = $this->prs->getById($perusahaan);
					$wilayah    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->ambilPerperusahaan($perusahaan);
				} elseif ($filter == '3'){
					$izin      = $_GET['izin'];
					$url_cetak = 'sumur/cetak?filter=3&izin='.$izin;
					$url_excel = 'sumur/excel?filter=3&izin='.$izin;
					if ($izin == '1') {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->getEndSipa()->result();
					} else {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->getEndTera()->result();
					}
				} elseif ($filter == '4'){
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$wilayah    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$url_cetak  = 'sumur/cetak?filter=4&jns_sumur='.$jns_sumur;
					$url_excel  = 'sumur/excel?filter=4&jns_sumur='.$jns_sumur;
					$ambil_data = $this->sumur->getJenisSumur($jns_sumur);
				}else {
					$zona       = $_GET['zona'];
					$wil        = $_GET['wilayah'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=5&wilayah='.$wil.'&zona='.$zona;
					$url_excel  = 'sumur/excel?filter=5&wilayah='.$wil.'&zona='.$zona;
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
			} else {
				$wilayah    = 'DAFTAR SUMUR';
				$url_cetak  = 'sumur/cetak';
				$url_excel  = 'sumur/excel';
				$ambil_data = $this->sumur->tampil();
			}
		} elseif ($this->session->userdata('akses')=='1' || $this->session->userdata('akses')=='5'){ // akses Admin Bandung
			//$wilayah = 'WILAYAH BANDUNG';
			$wil = '1';
			if (isset($_GET['filter1']) && !empty($_GET['filter1'])) {
				$filter = $_GET['filter1'];

				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=1&wilayah='.$wil;
					$url_excel = 'sumur/excel?filter=1&wilayah='.$wil;
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2'){
					$perusahaan = $_GET['perusahaan'];
					$url_cetak  = 'sumur/cetak?filter=2&perusahaan='.$perusahaan;
					$url_excel  = 'sumur/excel?filter=2&perusahaan='.$perusahaan;
					$wilayah    = 'DAFTAR SUMUR';
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3'){
					$izin      = $_GET['izin'];
					$url_cetak = 'sumur/cetak?filter=3&izin='.$izin;
					$url_excel = 'sumur/excel?filter=3&izin='.$izin;
					if ($izin == '1') {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndSipa($wil)->result();
					} else {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4'){
					$jns_sumur  = $_GET['jns_sumur'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=4&jns_sumur='.$jns_sumur;
					$url_excel  = 'sumur/excel?filter=4&jns_sumur='.$jns_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=5&zona='.$zona;
					$url_excel  = 'sumur/excel?filter=5&zona='.$zona;
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
			} else {
				$wilayah    = 'WILAYAH BANDUNG';
				$url_cetak  = 'sumur/cetak';
				$url_excel  = 'sumur/excel';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		} elseif ($this->session->userdata('akses')=='1' || $this->session->userdata('akses')=='4'){ //akses admin cimahi
			$wil = '2';
			if (isset($_GET['filter1']) && !empty($_GET['filter1'])) {
				$filter = $_GET['filter1'];

				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=1&wilayah='.$wil;
					$url_excel = 'sumur/excel?filter=1&wilayah='.$wil;
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2'){
					$perusahaan = $_GET['perusahaan'];
					$url_cetak  = 'sumur/cetak?filter=2&perusahaan='.$perusahaan;
					$url_excel  = 'sumur/excel?filter=2&perusahaan='.$perusahaan;
					$wilayah    = 'DAFTAR SUMUR';
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3'){
					$izin      = $_GET['izin'];
					$url_cetak = 'sumur/cetak?filter=3&izin='.$izin;
					$url_excel = 'sumur/excel?filter=3&izin='.$izin;
					if ($izin == '1') {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndSipa($wil)->result();
					} else {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4'){
					$jns_sumur  = $_GET['jns_sumur'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=4&jns_sumur='.$jns_sumur;
					$url_excel  = 'sumur/excel?filter=4&jns_sumur='.$jns_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=5&zona='.$zona;
					$url_excel  = 'sumur/excel?filter=5&zona='.$zona;
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
			} else {
				$wilayah    = 'WILAYAH CIMAHI';
				$url_cetak  = 'sumur/cetak';
				$url_excel  = 'sumur/excel';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
			
		} elseif ($this->session->userdata('akses')=='1' || $this->session->userdata('akses')=='6'){ //akses admin bandung barat
			$wil = '3';
			if (isset($_GET['filter1']) && !empty($_GET['filter1'])) {
				$filter = $_GET['filter1'];

				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=1&wilayah='.$wil;
					$url_excel = 'sumur/excel?filter=1&wilayah='.$wil;
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2'){
					$perusahaan = $_GET['perusahaan'];
					$url_cetak  = 'sumur/cetak?filter=2&perusahaan='.$perusahaan;
					$url_excel  = 'sumur/excel?filter=2&perusahaan='.$perusahaan;
					$wilayah    = 'DAFTAR SUMUR';
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3'){
					$izin      = $_GET['izin'];
					$url_cetak = 'sumur/cetak?filter=3&izin='.$izin;
					$url_excel = 'sumur/excel?filter=3&izin='.$izin;
					if ($izin == '1') {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndSipa($wil)->result();
					} else {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4'){
					$jns_sumur  = $_GET['jns_sumur'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=4&jns_sumur='.$jns_sumur;
					$url_excel  = 'sumur/excel?filter=4&jns_sumur='.$jns_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=5&zona='.$zona;
					$url_excel  = 'sumur/excel?filter=5&zona='.$zona;
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
			} else {
				$wilayah    = 'WILAYAH BANDUNG BARAT';
				$url_cetak  = 'sumur/cetak';
				$url_excel  = 'sumur/excel';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
			
		} elseif ($this->session->userdata('akses')=='1' || $this->session->userdata('akses')=='7'){ //akses admin subang
			$wil = '4';
			if (isset($_GET['filter1']) && !empty($_GET['filter1'])) {
				$filter = $_GET['filter1'];

				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=1&wilayah='.$wil;
					$url_excel = 'sumur/excel?filter=1&wilayah='.$wil;
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2'){
					$perusahaan = $_GET['perusahaan'];
					$url_cetak  = 'sumur/cetak?filter=2&perusahaan='.$perusahaan;
					$url_excel  = 'sumur/excel?filter=2&perusahaan='.$perusahaan;
					$wilayah    = 'DAFTAR SUMUR';
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3'){
					$izin      = $_GET['izin'];
					$url_cetak = 'sumur/cetak?filter=3&izin='.$izin;
					$url_excel = 'sumur/excel?filter=3&izin='.$izin;
					if ($izin == '1') {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndSipa($wil)->result();
					} else {
						$wilayah    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4'){
					$jns_sumur  = $_GET['jns_sumur'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=4&jns_sumur='.$jns_sumur;
					$url_excel  = 'sumur/excel?filter=4&jns_sumur='.$jns_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$wilayah    = 'DAFTAR SUMUR';
					$url_cetak  = 'sumur/cetak?filter=5&zona='.$zona;
					$url_excel  = 'sumur/excel?filter=5&zona='.$zona;
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
			} else {
				$wilayah    = 'WILAYAH SUBANG';
				$url_cetak  = 'sumur/cetak';
				$url_excel  = 'sumur/excel';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		}

		$data = [
			'title'       => 'SiESDM',
			'sub_title'   => 'Home',
			'page'        => 'Daftar Data Sumur',
			'jenis_sumur' => $this->jenis->view(),
			'wilayah'     => $wilayah,
			'url_cetak'   => $url_cetak,
			'url_excel'   => $url_excel,
			'f_wilayah'   => $this->sumur->wilayah(),
			'perusahaan'  => $this->prs->tampiPerusahaan(),
			'content'     => 'sumur/index',
			'sumur'       => $ambil_data
		];
		//print_r($data['sumur']);
		$this->load->view('template/template', $data);
	}


	public function detile($id_sumur = null){
		$data = [
			'title'     => 'SiESDM',
			'sub_title' => 'Home',
			'page'      => 'Data Rincian Sumur',
			'url_cetak' => 'sumur/cetakDetile',
			'sub_page'  => '',
			'content'   => 'sumur/detile',
			'sumur'     => $this->sumur->tampilByID($id_sumur)
		];
		$this->load->view('template/template', $data);
	}

	public function add(){
		$data = [
			'title' => 'SiESDM',
			'sub_title' => 'Home',
			'page' => 'Tambah Data Sumur',
			'sub_page' => '',
			'content' => 'sumur/add',
			'sumur' => $this->sumur->tampil(),
			'jenis' => $this->jenis->view(),
			'data' => $this->prs->tampiPerusahaan()
		];
		//print_r($data['perusahaan']);
		$this->load->view('template/template', $data);
	}

	public function save(){
		$this->sumur->add();
		redirect('sumur/add');	
	}

	public function edit($id_sumur = null){
		$data = [
			'title' => 'SiESDM',
			'sub_title' => 'Home',
			'page' => 'Ubah Data Sumur',
			'sub_page' => '',
			'content' => 'sumur/edit',
			'jenis' => $this->jenis->view(),
			'data' => $this->prs->tampiPerusahaan(),
			'sumur' => $this->sumur->getById($id_sumur)
		];
		//var_dump($data["sumur"]);
		$this->load->view('template/template', $data);
	} 

	public function update(){
		$this->sumur->update(); 
		redirect('sumur');	
	}

	public function delete($id_sumur = ''){
		if ($this->sumur->delete($id_sumur)) {
			redirect('sumur');
		}
	}

	public function cetak(){
		if ($this->session->userdata('akses')== '1') {
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->ambilPerperusahaan($perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->getEndSipa()->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->getEndTera()->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->getJenisSumur($jns_sumur);
				} else {
					$zona       = $_GET['zona'];
					$wil        = $_GET['wilayah'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
			} else {
				$ket       = 'DATA SUMUR';
				$ambil_data = $this->sumur->tampil();
			}
		} elseif ($this->session->userdata('akses')== '5') {
			$wil = '1';
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->abilEndSipa($wil)->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
				
			} else {
				$ket       = 'DATA SUMUR WILAYAH BANDUNG';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		} elseif ($this->session->userdata('akses')== '4') {
			$wil = '2';
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->abilEndSipa($wil)->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
				
			} else {
				$ket       = 'DATA SUMUR WILAYAH CIMAHI';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		} elseif ($this->session->userdata('akses')== '6') {
			$wil = '3';
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->abilEndSipa($wil)->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
				
			} else {
				$ket       = 'DATA SUMUR WILAYAH BANDUNG BARAT';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		} elseif ($this->session->userdata('akses')== '7') {
			$wil = '4';
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->abilEndSipa($wil)->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
				
			} else {
				$ket       = 'DATA SUMUR WILAYAH SUBANG';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		}

		$data = [
				'ket'      => $ket,
				'isi_data' => $ambil_data
		];
		$this->load->view('sumur/cetak', $data);
	}

	public function cetakDetile($id = null){
		$data['sumur'] = $this->sumur->tampilByID($id);
		$this->load->view('sumur/cetak_detile', $data);
	}

	public function excelDetile($id = null){
		$data['ket'] = 'Data Sumur';
		$data['sumur'] = $this->sumur->tampilByID($id);
		$this->load->view('exel/sumur_detile_excel', $data);
	}

	public function excel(){
		if ($this->session->userdata('akses')== '1') {
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->ambilPerperusahaan($perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->getEndSipa()->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->getEndTera()->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->getJenisSumur($jns_sumur);
				} else {
					$zona       = $_GET['zona'];
					$wil        = $_GET['wilayah'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
			} else {
				$ket       = 'DATA SUMUR';
				$ambil_data = $this->sumur->tampil();
			}
		} elseif ($this->session->userdata('akses')== '5') {
			$wil = '1';
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->abilEndSipa($wil)->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
				
			} else {
				$ket       = 'DATA SUMUR WILAYAH BANDUNG';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		} elseif ($this->session->userdata('akses')== '4') {
			$wil = '2';
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->abilEndSipa($wil)->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
				
			} else {
				$ket       = 'DATA SUMUR WILAYAH CIMAHI';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		} elseif ($this->session->userdata('akses')== '6') {
			$wil = '3';
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->abilEndSipa($wil)->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
				
			} else {
				$ket       = 'DATA SUMUR WILAYAH BANDUNG BARAT';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		} elseif ($this->session->userdata('akses')== '7') {
			$wil = '4';
			if (isset($_GET['filter']) && !empty($_GET['filter'])) {
				$filter = $_GET['filter'];
				if ($filter == '1') {
					$wil = $_GET['wilayah'];
					$nama_kota  = array('', 'KOTA BANDUNG', 'KOTA CIMAHI', 'KAB. BANDUNG BARAT', 'KAB. SUBANG');
					$ket    = 'DAFTAR SUMUR WILAYAH '.$nama_kota[$wil];
					$ambil_data = $this->sumur->ambilPerwilayah($wil);
				} elseif ($filter == '2') {
					$perusahaan = $_GET['perusahaan'];
					$nama_prs   = $this->prs->getById($perusahaan);
					$ket    = 'DAFTAR SUMUR '.$nama_prs->nama_perusahaan;
					$ambil_data = $this->sumur->getPerperusahaan($wil, $perusahaan);
				} elseif ($filter == '3') {
					$izin      = $_GET['izin'];
					if ($izin == '1') {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU SIPA AKAN HABIS';
						$ambil_data = $this->sumur->abilEndSipa($wil)->result();
					} else {
						$ket    = 'DAFTAR SUMUR YANG MASA BERLAKU TERA METER AIR AKAN HABIS';
						$ambil_data = $this->sumur->ambilEndTera($wil)->result();
					}
				} elseif ($filter == '4') {
					$jns_sumur  = $_GET['jns_sumur'];
					$jenis      = $this->jenis->getById($jns_sumur);
					$ket    = 'DAFTAR SUMUR '.$jenis->jenis_sumur;
					$ambil_data = $this->sumur->ambilJenisSumur($wil, $jns_sumur);
				} else {
					$zona  = $_GET['zona'];
					$nama_zona  =  array('','AMAN','RAWAN','KRITIS','RESAPAN');
					$ket        = 'DAFTAR SUMUR ZONA '.$nama_zona[$zona];
					$ambil_data = $this->sumur->getZona($wil, $zona);
				}
				
			} else {
				$ket       = 'DATA SUMUR WILAYAH SUBANG';
				$ambil_data = $this->sumur->ambilPerwilayah($wil);
			}
		}

		$data = [
				'ket'      => $ket,
				'isi_data' => $ambil_data
		];
		//print_r($data['perusahaan']);
		$this->load->view('exel/sumur_excel', $data);
	}	

	function downloadSipa($filename = NULL) {
	    // load download helder
	    $this->load->helper('download');
	    // read file contents
	    $data = file_get_contents(base_url('/uploads/sipa/'.$filename));
	    //echo json_encode($data);
	    force_download($filename, $data);
	}

	function downloadTera($filename = NULL) {
	    // load download helder
	    $this->load->helper('download');
	    // read file contents
	    $data = file_get_contents(base_url('/uploads/tera_meter/'.$filename));
	    //echo json_encode($data);
	    force_download($filename, $data);
	}

	function downloadUji($filename = NULL) {
	    // load download helder
	    $this->load->helper('download');
	    // read file contents
	    $data = file_get_contents(base_url('/uploads/uji_air/'.$filename));
	    //echo json_encode($data);
	    force_download($filename, $data);
	}

	function downloadPeta($filename = NULL) {
	    // load download helder
	    $this->load->helper('download');
	    // read file contents
	    $data = file_get_contents(base_url('/uploads/peta_sumur/'.$filename));
	    //echo json_encode($data);
	    force_download($filename, $data);
	}
}